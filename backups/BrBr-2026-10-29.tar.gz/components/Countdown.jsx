'use client';

import { useEffect, useState } from 'react';
import { launchConfetti } from '@/lib/confetti';

/* Interpreted in the viewer's local time zone, as in the original page. */
const TARGET = new Date('2027-07-27T16:00:00').getTime();

const pad = n => String(n).padStart(2, '0');

function split(diff) {
  return {
    days: pad(Math.floor(diff / 86400000)),
    hours: pad(Math.floor(diff % 86400000 / 3600000)),
    minutes: pad(Math.floor(diff % 3600000 / 60000)),
    seconds: pad(Math.floor(diff % 60000 / 1000)),
  };
}

const ZERO = { days: '00', hours: '00', minutes: '00', seconds: '00' };

/* Renders 00 on the server (the target is time-zone dependent), then
   ticks on the client. */
export default function Countdown() {
  const [left, setLeft] = useState(ZERO);
  const [arrived, setArrived] = useState(false);

  useEffect(() => {
    let timer;
    const update = () => {
      const diff = TARGET - Date.now();
      if (diff <= 0) {
        setLeft(ZERO);
        setArrived(true);
        launchConfetti();
        clearInterval(timer);
        return;
      }
      setLeft(split(diff));
    };
    update();
    timer = setInterval(update, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <>
      <p className="section-sub reveal">{arrived ? 'لقد حلّ اليوم الموعود! 🎉' : 'لحظاتٌ تفصلنا عن أجمل يوم'}</p>

      <div className="date-badge reveal">٢٧ يوليو ٢٠٢٧</div>

      <div className="countdown reveal" role="timer" aria-live="off">
        <div className="count-card"><div className="num">{left.days}</div><div className="lbl">يوم</div></div>
        <div className="count-card"><div className="num">{left.hours}</div><div className="lbl">ساعة</div></div>
        <div className="count-card"><div className="num">{left.minutes}</div><div className="lbl">دقيقة</div></div>
        <div className="count-card"><div className="num">{left.seconds}</div><div className="lbl">ثانية</div></div>
      </div>
    </>
  );
}
