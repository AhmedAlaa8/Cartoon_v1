# دعوة فرح — أحمد & عبير (Next.js)

```bash
npm install
npm run dev        # تطوير على http://localhost:3000
npm run build && npm start   # النسخة النهائية
```

## البنية
| المسار | الدور |
|---|---|
| `app/layout.jsx` | `lang="ar" dir="rtl"`، الخطوط عبر `next/font` (بدون طلب لـ Google وقت التصفّح) |
| `app/page.jsx` | الصفحة — تُولَّد static وقت البناء |
| `app/api/rsvp/route.js` | تأكيد الحضور → `rsvp.json` (كتابة متسلسلة وذرّية) |
| `components/Hall.jsx` | القاعة والأبواب: يحمّل باب three.js بعد أول رسم، وباب CSS احتياطي |
| `lib/doorScene.js` | مشهد الباب ثلاثي الأبعاد (three.js) — خشب جوز + نحاس؛ للمعاينة: `?door=wood-iron` (بلوط + حديد) أو `?door=lacquer` (أسود + دهب) |
| `lib/doorPhases.js` | مراحل الفتح (فكّ القفل ← دوران الضلفتين ← دخول الكاميرا) المشتركة بين البابين |
| `public/assets/` | صور العروسين (اختياري) — انظر `README.txt` |
| `legacy/` | النسخة القديمة (HTML/CSS/JS + `server.js`) للرجوع إليها |

## ملاحظات
- العدّ التنازلي محسوب بتوقيت جهاز الزائر (كما في النسخة القديمة)؛ لو أردت توقيت القاهرة ثابتًا اكتب
  `2027-07-27T16:00:00+03:00` في `components/Countdown.jsx`.
- `rsvp.json` يحتاج سيرفر Node دائم (`npm start`)؛ على Vercel لا يُحفظ.
