import fs from 'node:fs';
import path from 'node:path';
import CinematicApp from '@/components/cinematic/CinematicApp';
import './cinematic.css';

/* Preview of the cinematic invitation — reached via /?theme=cinematic
   (redirected here) or /cinematic directly. Not the default yet. */
export const metadata = {
  title: 'دعوة فرح 💍 — أحمد & عبير',
  robots: { index: false, follow: false },
};

function findPhoto(name) {
  for (const ext of ['jpg', 'jpeg', 'png', 'webp']) {
    const file = `${name}.${ext}`;
    if (fs.existsSync(path.join(process.cwd(), 'public', 'assets', file))) return `/assets/${file}`;
  }
  return null;
}

export default function CinematicPage() {
  return <CinematicApp photos={{ groom: findPhoto('groom'), bride: findPhoto('bride') }} />;
}
