import Loader from '@/components/Loader';
import Backdrop from '@/components/Backdrop';
import MusicButton from '@/components/MusicButton';
import Hall from '@/components/Hall';
import Countdown from '@/components/Countdown';
import Couple from '@/components/Couple';
import Rsvp from '@/components/Rsvp';
import RevealObserver from '@/components/RevealObserver';

export default function Home() {
  return (
    <>
      <noscript>
        <style>{'.loader{display:none}.reveal{opacity:1;transform:none}.hero-inner{opacity:1;transform:none}'}</style>
      </noscript>

      <Loader />
      <Backdrop />
      {/* ?theme=night: the page-wide night sky + the wish invitation */}
      <canvas id="night-canvas" className="night-canvas" aria-hidden="true" />
      <div id="wish-hint" className="wish-hint" aria-hidden="true">المس السماء وأضف نجمتك لليلتنا ✨</div>
      <MusicButton />

      <Hall />

      <section id="countdown" className="scope">
        <h2 className="section-title reveal">العدّ التنازلي ليوم العمر</h2>
        <Countdown />
      </section>

      <Couple />

      <Rsvp />

      <footer>
        <div className="rule"><span />❖<span /></div>
        <div className="verse">&quot;ومن آياته أن خلق لكم من أنفسكم أزواجًا لتسكنوا إليها وجعل بينكم مودّةً ورحمة&quot;</div>
        <div className="small">بدعوةٍ من عائلتَي العروسين — نتشرّف بحضوركم وبركة دعواتكم ✨</div>
      </footer>

      <RevealObserver />
    </>
  );
}
