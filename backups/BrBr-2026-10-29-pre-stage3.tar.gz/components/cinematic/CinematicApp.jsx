'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { WEDDING, weddingInstant } from '@/lib/wedding';

/* ================================================================
   Cinematic preview shell (Stage 1): six chapters, no page scroll.
   Next = swipe left→right (RTL), the ‹ arrow, ←, PageDown/Space or
   the mouse wheel; each chapter has its own #hash. The 3D world
   (lib/cinematic/scene.js) loads after first paint; the camera
   travels between the chapters' stations.
================================================================ */

const CHAPTERS = [
  { id: 'door', title: 'الباب' },
  { id: 'names', title: 'الأسماء' },
  { id: 'countdown', title: 'العدّ التنازلي' },
  { id: 'couple', title: 'العروسان' },
  { id: 'rsvp', title: 'تأكيد الحضور' },
  { id: 'sky', title: 'الختام' },
];
const indexOfHash = () => Math.max(0, CHAPTERS.findIndex(c => `#${c.id}` === window.location.hash));
// an SVG chevron: text arrows (‹ ›) are mirrored by the RTL bidi algorithm
const Chevron = ({ to }) => (
  <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true">
    <path d={to === 'left' ? 'M15 5l-7 7 7 7' : 'M9 5l7 7-7 7'} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
// a navy-enamel map pin with a gold jewel — drawn, not an emoji
const PinIcon = () => (
  <svg className="cine-icon" viewBox="0 0 32 40" width="24" height="30" aria-hidden="true">
    <defs>
      <radialGradient id="pinBody" cx="35%" cy="28%" r="80%">
        <stop offset="0" stopColor="#3d5cab" /><stop offset=".55" stopColor="#17264f" /><stop offset="1" stopColor="#0a1230" />
      </radialGradient>
      <linearGradient id="pinRim" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor="#fff4d6" /><stop offset=".5" stopColor="#c99a4b" /><stop offset="1" stopColor="#7c5622" />
      </linearGradient>
      <radialGradient id="pinJewel" cx="38%" cy="32%" r="70%">
        <stop offset="0" stopColor="#fff8e6" /><stop offset=".5" stopColor="#e3c27e" /><stop offset="1" stopColor="#9a6c2c" />
      </radialGradient>
    </defs>
    <ellipse cx="16" cy="37.6" rx="6.5" ry="1.8" fill="rgba(60,35,5,.35)" />
    <path d="M16 1.5C8.3 1.5 3 7.3 3 14.6 3 23.8 16 36.5 16 36.5S29 23.8 29 14.6C29 7.3 23.7 1.5 16 1.5z" fill="url(#pinBody)" stroke="url(#pinRim)" strokeWidth="1.7" />
    <circle cx="16" cy="14.6" r="5.4" fill="url(#pinJewel)" stroke="#7c5622" strokeWidth=".6" />
    <ellipse cx="11" cy="8.4" rx="3.6" ry="2" fill="rgba(255,255,255,.32)" transform="rotate(-32 11 8.4)" />
  </svg>
);

// an engraved key on the door coin
const KeyIcon = () => (
  <svg className="cine-icon" viewBox="0 0 40 40" width="34" height="34" aria-hidden="true">
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      <g stroke="#13204a" strokeWidth="3.2">
        <circle cx="20" cy="12" r="6" /><path d="M20 18v16M20 27h5.5M20 31.5h4" />
      </g>
      <g stroke="rgba(255,248,230,.55)" strokeWidth="1" transform="translate(-.7 -.9)">
        <path d="M15.2 9.6a6 6 0 0 1 6.6-3.2" /><path d="M20 19v13" />
      </g>
    </g>
  </svg>
);

const HeartIcon = () => (
  <svg className="cine-icon" viewBox="0 0 24 22" width="20" height="18" aria-hidden="true">
    <defs>
      <radialGradient id="heartGem" cx="35%" cy="30%" r="80%">
        <stop offset="0" stopColor="#ffe7ec" /><stop offset=".5" stopColor="#e9a9b8" /><stop offset="1" stopColor="#a65468" />
      </radialGradient>
    </defs>
    <path d="M12 20.5S2 14.2 2 7.6C2 4.5 4.4 2 7.3 2c2 0 3.7 1.1 4.7 2.8C13 3.1 14.7 2 16.7 2 19.6 2 22 4.5 22 7.6c0 6.6-10 12.9-10 12.9z" fill="url(#heartGem)" stroke="#7c5622" strokeWidth=".8" />
    <ellipse cx="7.6" cy="6.6" rx="2.4" ry="1.4" fill="rgba(255,255,255,.45)" transform="rotate(-30 7.6 6.6)" />
  </svg>
);

const toArabic = s => String(s).replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);

/* on the venue's clock (lib/wedding.js) */
const TARGET = weddingInstant();
const pad = n => String(n).padStart(2, '0');

function useCountdown() {
  const [left, setLeft] = useState(null);
  useEffect(() => {
    const tick = () => {
      const d = Math.max(0, TARGET - Date.now());
      setLeft({
        days: Math.floor(d / 86400000), hours: pad(Math.floor(d % 86400000 / 3600000)),
        minutes: pad(Math.floor(d % 3600000 / 60000)), seconds: pad(Math.floor(d % 60000 / 1000)),
      });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return left;
}

function Medallion({ caption, photo, kind }) {
  return (
    <figure className="cine-person">
      <div className={`cine-medallion ${kind}`}>
        {photo
          ? <img src={photo} alt={caption} />
          : kind === 'groom'
            ? <svg viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="40" r="19" /><path d="M28 112C28 82 43 72 60 72s32 10 32 40" /><path d="M50 73l10 19 10-19" /></svg>
            : <svg viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="42" r="17" /><path d="M32 112C32 84 46 74 60 74s28 10 28 38" /><path d="M40 30Q60 12 80 30" /><path d="M30 58Q33 98 46 112" /><path d="M90 58Q87 98 74 112" /></svg>}
      </div>
      <figcaption>{caption}</figcaption>
    </figure>
  );
}

export default function CinematicApp({ photos = {} }) {
  const root = useRef(null);
  const canvas = useRef(null);
  const scene = useRef(null);
  const busy = useRef(false);
  const [index, setIndex] = useState(0);         // where we are going (dots, hash)
  const [shown, setShown] = useState(0);         // whose words are on screen — only once the camera has arrived
  const [dir, setDir] = useState(1);
  const [ready, setReady] = useState(false);
  const left = useCountdown();

  /* the page itself never scrolls in this mode */
  useEffect(() => {
    document.documentElement.classList.add('cine-mode');
    return () => document.documentElement.classList.remove('cine-mode');
  }, []);

  const go = useCallback(async target => {
    if (target < 0 || target >= CHAPTERS.length || busy.current) return;
    const from = scene.current ? scene.current.index : index;
    if (target === from) return;
    busy.current = true;
    setDir(target > from ? 1 : -1);
    setIndex(target);
    setShown(-1);
    history.replaceState(null, '', `#${CHAPTERS[target].id}`);
    try {
      await scene.current?.goTo(target);
    } finally {
      busy.current = false;
      setShown(target);
    }
  }, [index]);

  /* load the world after first paint */
  useEffect(() => {
    const start = indexOfHash();
    setIndex(start);
    setShown(start);
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let disposed = false;
    const load = async () => {
      const [{ createCinematicScene }, { webglAvailable }] = await Promise.all([import('@/lib/cinematic/scene'), import('@/lib/doorScene')]);
      if (disposed || !webglAvailable()) return;
      scene.current = createCinematicScene(canvas.current, {
        reducedMotion: reduced,
        start: CHAPTERS[start].id,
        // ?slowmo=N slows the world N× — for reviewing transitions frame by frame
        slowmo: Math.max(1, Number(new URLSearchParams(window.location.search).get('slowmo')) || 1),
        onContextLost: () => { scene.current = null; setReady(false); },
      });
      setReady(true);
    };
    const idle = window.requestIdleCallback || (cb => setTimeout(cb, 120));
    idle(() => { load().catch(() => {}); }, { timeout: 800 });
    const onResize = () => scene.current?.resize();
    window.addEventListener('resize', onResize);
    return () => { disposed = true; scene.current?.dispose(); scene.current = null; window.removeEventListener('resize', onResize); };
  }, []);

  /* keyboard, wheel, hash */
  useEffect(() => {
    const onKey = e => {
      if (e.target.closest?.('input, textarea, select')) return;
      if (['ArrowLeft', 'PageDown', ' '].includes(e.key)) { e.preventDefault(); go(index + 1); }
      if (['ArrowRight', 'PageUp'].includes(e.key)) { e.preventDefault(); go(index - 1); }
    };
    let acc = 0, quietUntil = 0;
    const onWheel = e => {
      if (e.target.closest?.('[data-scroll]')) return;
      e.preventDefault();
      const now = performance.now();
      if (now < quietUntil) return;
      acc += e.deltaY;
      if (Math.abs(acc) > 60) {
        go(index + Math.sign(acc));
        acc = 0;
        quietUntil = now + 900;      // one gesture, one chapter
      }
    };
    const onHash = () => go(indexOfHash());
    window.addEventListener('keydown', onKey);
    window.addEventListener('wheel', onWheel, { passive: false });
    window.addEventListener('hashchange', onHash);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('wheel', onWheel);
      window.removeEventListener('hashchange', onHash);
    };
  }, [go, index]);

  /* swipe (left→right = next) and taps */
  const touch = useRef(null);
  const onPointerDown = e => {
    if (e.target.closest('button, a, input, textarea, select, label, [data-no-swipe]')) { touch.current = null; return; }
    touch.current = { x: e.clientX, y: e.clientY, t: performance.now() };
  };
  const onPointerUp = e => {
    const s = touch.current;
    touch.current = null;
    if (!s) return;
    const dx = e.clientX - s.x, dy = e.clientY - s.y, dt = performance.now() - s.t;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.4) { go(index + (dx > 0 ? 1 : -1)); return; }
    if (Math.abs(dx) < 10 && Math.abs(dy) < 10 && dt < 500) {
      if (CHAPTERS[index].id === 'door') go(1);                 // tap the door to enter
      else scene.current?.wish(e.clientX, e.clientY);           // touch the sky (final chapter)
    }
  };

  const c = shown >= 0 ? CHAPTERS[shown].id : null;
  const chapterClass = id => `cine-chapter cine-${id}${c === id ? ' is-active' : ''}`;
  const inactive = id => (c === id ? {} : { inert: true, 'aria-hidden': true });

  return (
    <div
      className={`cine${ready ? ' is-ready' : ''}`}
      data-dir={dir > 0 ? 'next' : 'prev'}
      ref={root}
      onPointerDown={onPointerDown}
      onPointerUp={onPointerUp}
    >
      <canvas className="cine-canvas" ref={canvas} aria-hidden="true" />

      <section className={chapterClass('door')} {...inactive('door')} aria-label="الباب">
        <div className="cine-hint">
          <button type="button" className="cine-enter" onClick={() => go(1)} aria-label="افتح الباب وادخل"><KeyIcon /></button>
          <p>اضغط على الباب للدخول</p>
        </div>
      </section>

      <section className={chapterClass('names')} {...inactive('names')} aria-label="أحمد وعبير">
        <p className="cine-eyebrow">بسم الله نبدأ حكايتنا</p>
        <h1 className="cine-sr">أحمد ♥ عبير</h1>
        <p className="cine-stage-note">هنا ستكتب الألعاب النارية الأسماء<br /><small>المرحلة ٤</small></p>
      </section>

      <section className={chapterClass('countdown')} {...inactive('countdown')} aria-label="العدّ التنازلي">
        <h2 className="cine-title">العدّ التنازلي ليوم العمر</h2>
        <p className="cine-date">{WEDDING.dateLabelAr}</p>
        <div className="cine-count" role="timer" aria-live="off">
          {[['days', 'يوم'], ['hours', 'ساعة'], ['minutes', 'دقيقة'], ['seconds', 'ثانية']].map(([k, label], i) => (
            <div className="cine-unit" key={k}>
              {i > 0 && <span className="cine-sep" aria-hidden="true">❖</span>}
              <span className="cine-num">{left ? toArabic(left[k]) : '٠٠'}</span>
              <span className="cine-lbl">{label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={chapterClass('couple')} {...inactive('couple')} aria-label="العروسان">
        <h2 className="cine-title">العروسان</h2>
        <div className="cine-pair">
          <Medallion kind="groom" caption="العريس أحمد" photo={photos.groom} />
          <span className="cine-heart" aria-hidden="true">♥</span>
          <Medallion kind="bride" caption="العروس عبير" photo={photos.bride} />
        </div>
      </section>

      <section className={chapterClass('rsvp')} {...inactive('rsvp')} aria-label="تأكيد الحضور">
        <h2 className="cine-title">شرّفونا بحضوركم</h2>
        <p className="cine-text">
          يسعدنا ويشرّفنا دعوتكم لمشاركتنا فرحة العمر، فحضوركم تاجٌ على رؤوسنا وبهجةٌ لقلوبنا.
        </p>
        <div className="cine-venue">
          <svg className="cine-flourish" viewBox="0 0 220 24" aria-hidden="true">
            <path d="M4 12 C40 12 60 2 92 10 M216 12 C180 12 160 2 128 10" />
            <path d="M110 4 l6 8 -6 8 -6 -8z" />
          </svg>
          <p className="cine-venue-name">قاعة <bdi>Eventa</bdi></p>
          <p className="cine-venue-city">{WEDDING.venue.city} – {WEDDING.venue.country}</p>
          <a className="cine-btn cine-map" href={WEDDING.venue.mapsUrl} target="_blank" rel="noopener noreferrer">
            <PinIcon /><span>عرض موقع القاعة</span>
          </a>
        </div>
        <div className="cine-rsvp-cta">
          <button type="button" className="cine-btn" aria-disabled="true" title="يعمل في المرحلة ٥"><span>أؤكّد حضوري</span><HeartIcon /></button>
          <p className="cine-stage-small">شكل الزر فقط — النموذج يعمل في المرحلة ٥</p>
        </div>
      </section>

      <section className={chapterClass('sky')} {...inactive('sky')} aria-label="الختام">
        <p className="cine-verse">«ومن آياته أن خلق لكم من أنفسكم أزواجًا لتسكنوا إليها وجعل بينكم مودّةً ورحمة»</p>
        <p className="cine-wish">المس السماء وأضف نجمتك لليلتنا ✨</p>
      </section>

      <nav className="cine-nav" aria-label="فصول الدعوة">
        <button type="button" className="cine-arrow prev" onClick={() => go(index - 1)} disabled={index === 0} aria-label="الفصل السابق"><Chevron to="right" /></button>
        <div className="cine-dots">
          {CHAPTERS.map((ch, i) => (
            <button
              type="button" key={ch.id} className={`cine-dot${i === index ? ' is-active' : ''}`}
              onClick={() => go(i)} aria-label={ch.title} aria-current={i === index ? 'step' : undefined}
            />
          ))}
        </div>
        <button type="button" className="cine-arrow next" onClick={() => go(index + 1)} disabled={index === CHAPTERS.length - 1} aria-label="الفصل التالي"><Chevron to="left" /></button>
      </nav>
      <p className="cine-sr" aria-live="polite">{`${toArabic(index + 1)} من ٦: ${CHAPTERS[index].title}`}</p>
    </div>
  );
}
