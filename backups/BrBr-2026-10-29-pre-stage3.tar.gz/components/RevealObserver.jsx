'use client';

import { useEffect } from 'react';

/* One IntersectionObserver for the whole page instead of reading every
   element's position on every scroll frame:
   • .reveal elements get .in once they enter the viewport;
   • .scope sections get [data-inview] while visible, which lets CSS pause
     their looping animations when they are off-screen. */
export default function RevealObserver() {
  useEffect(() => {
    const reveals = document.querySelectorAll('.reveal');
    const scopes = document.querySelectorAll('.scope');

    const revealIO = new IntersectionObserver(entries => {
      for (const e of entries) {
        if (!e.isIntersecting) continue;
        e.target.classList.add('in');
        revealIO.unobserve(e.target);
      }
    }, { rootMargin: '0px 0px -12% 0px' });

    const scopeIO = new IntersectionObserver(entries => {
      for (const e of entries) e.target.toggleAttribute('data-inview', e.isIntersecting);
    });

    reveals.forEach(el => revealIO.observe(el));
    scopes.forEach(el => scopeIO.observe(el));

    return () => { revealIO.disconnect(); scopeIO.disconnect(); };
  }, []);

  return null;
}
