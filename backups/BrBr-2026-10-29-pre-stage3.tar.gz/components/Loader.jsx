'use client';

import { useEffect, useRef } from 'react';

/* Hides as soon as the fonts are ready (min 600ms so it never flashes,
   max 1800ms so a slow network never holds the page hostage). */
export default function Loader() {
  const ref = useRef(null);

  useEffect(() => {
    const started = performance.now();
    let done = false;
    const hide = () => {
      if (done) return;
      done = true;
      ref.current?.classList.add('hidden');
    };
    const cap = setTimeout(hide, 1800);
    document.fonts?.ready.then(() => {
      setTimeout(hide, Math.max(0, 600 - (performance.now() - started)));
    });
    return () => clearTimeout(cap);
  }, []);

  return (
    <div className="loader" ref={ref} aria-hidden="true">
      <div className="loader-ring"><span className="loader-mono">💍</span></div>
      <div className="loader-text">دعوة فرح</div>
    </div>
  );
}
