'use client';

import { useEffect, useRef, useState } from 'react';

/* Soft ambient pad synthesised with Web Audio — no audio file to download.
   The AudioContext is only created on the first tap. */
const CHORD = [196.0, 246.94, 293.66, 392.0, 493.88]; // warm, low

function buildPad() {
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  const master = ctx.createGain();
  master.gain.value = 0;
  master.connect(ctx.destination);

  const filter = ctx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.value = 850;
  filter.connect(master);

  CHORD.forEach((f, idx) => {
    const osc = ctx.createOscillator();
    osc.type = idx % 2 ? 'sine' : 'triangle';
    osc.frequency.value = f;
    const g = ctx.createGain();
    g.gain.value = 0.12 / CHORD.length;
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.07 + idx * 0.02;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 0.04;
    lfo.connect(lfoGain).connect(g.gain);
    osc.connect(g).connect(filter);
    osc.start(); lfo.start();
  });

  return { ctx, master };
}

export default function MusicButton() {
  const audio = useRef(null);
  const [playing, setPlaying] = useState(false);

  useEffect(() => () => { audio.current?.ctx.close(); }, []);

  const toggle = () => {
    if (!audio.current) audio.current = buildPad();
    const { ctx, master } = audio.current;
    if (ctx.state === 'suspended') ctx.resume();

    const next = !playing;
    master.gain.cancelScheduledValues(ctx.currentTime);
    master.gain.setValueAtTime(master.gain.value, ctx.currentTime);
    master.gain.linearRampToValueAtTime(next ? 0.6 : 0, ctx.currentTime + (next ? 2 : 1.2));
    setPlaying(next);
  };

  return (
    <button
      type="button"
      className={`music-btn${playing ? ' playing' : ''}`}
      onClick={toggle}
      title="موسيقى رومانسية"
      aria-label={playing ? 'إيقاف الموسيقى' : 'تشغيل الموسيقى'}
      aria-pressed={playing}
    >
      {playing ? '🎶' : '🎵'}
    </button>
  );
}
