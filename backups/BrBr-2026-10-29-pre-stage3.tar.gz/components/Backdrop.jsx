/* Static background layers + a fixed pool of gold dust particles.
   A server component: rendered once into the HTML, no client JS.
   A seeded PRNG keeps the particle layout identical between builds. */

const PARTICLES = 22;

function seeded(seed) {
  let s = seed;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function dust() {
  const rand = seeded(27072027);
  return Array.from({ length: PARTICLES }, (_, i) => {
    const size = 3 + rand() * 5;
    const dur = 9 + rand() * 9;
    return {
      key: i,
      style: {
        width: `${size.toFixed(1)}px`,
        height: `${size.toFixed(1)}px`,
        left: `${(rand() * 100).toFixed(2)}%`,
        animationDuration: `${dur.toFixed(1)}s`,
        animationDelay: `${(-rand() * dur).toFixed(1)}s`,
      },
    };
  });
}

export default function Backdrop() {
  return (
    <>
      <div className="bg" />
      <div className="vignette" />
      <div className="grain" />
      <div className="dust-layer" aria-hidden="true">
        {dust().map(d => <span key={d.key} className="dust" style={d.style} />)}
      </div>
    </>
  );
}
