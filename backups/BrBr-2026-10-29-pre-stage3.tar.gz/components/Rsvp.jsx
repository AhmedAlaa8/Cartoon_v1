'use client';

import { useEffect, useRef, useState } from 'react';
import { launchConfetti } from '@/lib/confetti';

/* RSVP — the guest writes their name and party size; the API route
   appends it to rsvp.json. Success is only shown once it is saved. */
export default function Rsvp() {
  const [open, setOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [status, setStatus] = useState({ text: '', error: false });
  const [thanks, setThanks] = useState(false);
  const openBtn = useRef(null);
  const nameIn = useRef(null);
  const form = useRef(null);
  const closeTimer = useRef(null);

  useEffect(() => {
    if (!open) return;
    const focus = setTimeout(() => nameIn.current?.focus(), 250);
    const onKey = e => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', onKey);
    return () => { clearTimeout(focus); document.removeEventListener('keydown', onKey); };
  }, [open]);

  useEffect(() => () => clearTimeout(closeTimer.current), []);

  function close() {
    setOpen(false);
    openBtn.current?.focus();
  }

  async function submit(e) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const name = String(data.get('name') || '').trim();
    if (!name) { nameIn.current?.focus(); return; }
    const count = Math.min(50, Math.max(1, parseInt(data.get('count'), 10) || 1));

    setSending(true);
    setStatus({ text: 'جارٍ الإرسال…', error: false });
    try {
      const res = await fetch('/api/rsvp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, count }),
      });
      if (!res.ok) throw new Error(String(res.status));

      setStatus({ text: `تم تأكيد حضورك يا ${name} 💛`, error: false });
      setThanks(true);
      launchConfetti();
      form.current?.reset();
      closeTimer.current = setTimeout(close, 1600);
    } catch {
      setStatus({ text: 'تعذّر حفظ التأكيد، حاول مرة أخرى من فضلك', error: true });
    } finally {
      setSending(false);
    }
  }

  return (
    <>
      <section id="rsvp" className="scope">
        <h2 className="section-title reveal">شرّفونا بحضوركم</h2>
        <p className="rsvp-text reveal">
          يسعدنا ويشرّفنا دعوتكم لمشاركتنا فرحة العمر،
          فحضوركم تاجٌ على رؤوسنا وبهجةٌ لقلوبنا.
          نترقّب لحظة لقائكم لنبدأ معًا أجمل الذكريات.
        </p>
        <button
          type="button"
          className="btn reveal"
          ref={openBtn}
          onClick={() => { setStatus({ text: '', error: false }); setOpen(true); }}
        >
          أؤكّد حضوري 🎉
        </button>
        <div className={`thanks${thanks ? ' show' : ''}`} aria-live="polite">
          {thanks && 'شكرًا لكم 💛 بانتظاركم بفارغ الصبر'}
        </div>
      </section>

      <div
        className={`rsvp-modal${open ? ' open' : ''}`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="rsvp-title"
        aria-hidden={!open}
        inert={!open}
        onClick={e => { if (e.target === e.currentTarget) close(); }}
      >
        <div className="rsvp-card">
          <button type="button" className="rsvp-close" onClick={close} aria-label="إغلاق">&times;</button>
          <div className="rsvp-ring" aria-hidden="true">💍</div>
          <h3 id="rsvp-title">تأكيد الحضور</h3>
          <p>سعداء بمشاركتكم فرحتنا — من فضلك اكتب اسمك</p>
          <form ref={form} onSubmit={submit}>
            <input ref={nameIn} type="text" name="name" placeholder="الاسم الكريم" autoComplete="name" maxLength={80} required aria-label="الاسم" />
            <input type="number" name="count" placeholder="عدد الأفراد" min="1" max="50" defaultValue="1" inputMode="numeric" aria-label="عدد الأفراد" />
            <button type="submit" className="btn" disabled={sending}>إرسال التأكيد 🎉</button>
          </form>
          <div className={`rsvp-status${status.error ? ' error' : ''}`} role="status">{status.text}</div>
        </div>
      </div>
    </>
  );
}
