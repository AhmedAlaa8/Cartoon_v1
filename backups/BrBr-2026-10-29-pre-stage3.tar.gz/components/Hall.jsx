'use client';

import { useEffect, useRef, useState } from 'react';
import Typing from './Typing';
import { clamp, easeInOut, easeOut, phases, range } from '@/lib/doorPhases';

/* ================================================================
   HALL — grand arched doorway that opens on scroll (or on tap).
   The door itself is a three.js scene (lib/doorScene.js), loaded after
   first paint; until it is ready — or if WebGL is unavailable — the
   CSS door below stands in, on the same timeline (lib/doorPhases.js).
   With ?theme=night the door is part of a whole world instead
   (lib/night/scene.js, drawn on the page-wide #night-canvas): the
   camera walks through it into a garden by a lake under fireworks.
   One rAF per scroll frame reads window.scrollY only (geometry is
   cached on resize), then writes transforms/opacity straight onto
   the handful of moving elements — no React re-render, no layout.
================================================================ */

const isNight = () => document.documentElement.dataset.theme === 'night';

// the night scene's cues: reveal the names, then invite a wish
function nightCue(hero) {
  return cue => {
    if (cue === 'names' && hero.current) {
      hero.current.dataset.cued = '';          // from now on the names show whenever the walk is done
      hero.current.classList.add('revealed');
    }
    if (cue === 'wish-hint') {
      const el = document.getElementById('wish-hint');
      el?.classList.add('show');
      setTimeout(() => el?.classList.remove('show'), 7000);
    }
  };
}

const MAX_ANGLE = 96;          // degrees each leaf swings into the hall
const AUTO_OPEN_MS = 3400;     // duration of the tap-to-open walk-through

function Ornament({ className }) {
  return (
    <svg className={className} viewBox="0 0 120 120" aria-hidden="true">
      <g fill="none" stroke="currentColor" strokeWidth="1.3">
        <circle cx="60" cy="60" r="49" />
        {[0, 45, 90, 135, 180, 225, 270, 315].map(a => (
          <ellipse key={a} cx="60" cy="33" rx="8.5" ry="23" transform={`rotate(${a} 60 60)`} />
        ))}
        <circle cx="60" cy="60" r="9" />
      </g>
    </svg>
  );
}

function Lozenge() {
  return (
    <svg className="lozenge" viewBox="0 0 60 60" aria-hidden="true">
      <g fill="none" stroke="currentColor" strokeWidth="1.4">
        <path d="M30 3 57 30 30 57 3 30Z" />
        <path d="M30 14 46 30 30 46 14 30Z" />
        <circle cx="30" cy="30" r="3.5" />
      </g>
    </svg>
  );
}

function Leaf({ side, leafRef }) {
  return (
    <div className={`leaf ${side}`} ref={leafRef}>
      <div className="panel upper"><Ornament className="ornament" /></div>
      <div className="panel lower"><Lozenge /></div>
      <span className="knocker" />
      <span className="boss" />
    </div>
  );
}

export default function Hall() {
  const hall = useRef(null);
  const stage = useRef(null);
  const facade = useRef(null);
  const left = useRef(null);
  const right = useRef(null);
  const dial = useRef(null);
  const seam = useRef(null);
  const flood = useRef(null);
  const glow = useRef(null);
  const rays = useRef(null);
  const hero = useRef(null);
  const hint = useRef(null);
  const canvas = useRef(null);
  const autoOpen = useRef(null);
  const [opened, setOpened] = useState(false);

  useEffect(() => {
    const night = isNight();
    const html = document.documentElement;

    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setOpened(true);
      if (!night) return;
      // still garden, no fireworks
      let still = null, gone = false;
      Promise.all([import('@/lib/night/scene'), import('@/lib/doorScene')]).then(([{ createNightScene }, { webglAvailable }]) => {
        if (gone || !webglAvailable()) return;
        still = createNightScene(document.getElementById('night-canvas'), { reducedMotion: true, onIntro: nightCue(hero) });
        html.setAttribute('data-night-gl', '');
      }).catch(() => {});
      const onResize = () => still?.resize();
      window.addEventListener('resize', onResize);
      return () => { gone = true; still?.dispose(); window.removeEventListener('resize', onResize); };
    }

    let top = 0, total = 1, bottom = 0, afterTotal = 1, frame = 0, last = -1;
    let wasOpen = false, wasLive = null;
    let door = null, nightGL = false, disposed = false;

    const measure = () => {
      const rect = hall.current.getBoundingClientRect();
      top = rect.top + window.scrollY;
      total = Math.max(1, hall.current.offsetHeight - window.innerHeight);
      bottom = top + hall.current.offsetHeight;
      afterTotal = Math.max(1, document.documentElement.scrollHeight - window.innerHeight - (top + total));
    };

    const render = () => {
      frame = 0;
      const y = window.scrollY;
      const live = y < bottom;
      if (live !== wasLive) {
        wasLive = live;
        stage.current.toggleAttribute('data-live', live);
        door?.setLive?.(live);
      }

      const p = clamp((y - top) / total);
      // the night sky keeps moving below the hall, so it follows every scroll
      const key = nightGL ? y : p;
      if (key === last) return;
      last = key;

      const isOpen = p > 0.12;
      if (isOpen !== wasOpen) {
        wasOpen = isOpen;
        stage.current.toggleAttribute('data-open', isOpen);
      }
      hint.current.style.opacity = (1 - range(p, 0, 0.06)).toFixed(3);
      hint.current.style.visibility = p > 0.06 ? 'hidden' : '';

      if (nightGL) {
        // the names belong to the garden: hidden again if the guest scrolls back to the door
        hero.current.classList.toggle('revealed', 'cued' in hero.current.dataset && p > 0.95);
        door.setProgress(p);
        door.setAfter((y - top - total) / afterTotal);
        return;
      }

      const { unlock: u, dialFade, swing: s, enter: c, leak } = phases(p);

      if (door) {
        door.setProgress(p);
      } else {
        dial.current.style.transform = `rotate(${(u * 180).toFixed(1)}deg)`;
        dial.current.style.opacity = (1 - dialFade).toFixed(3);
        seam.current.style.opacity = (u * (1 - leak)).toFixed(3);

        const angle = (s * MAX_ANGLE).toFixed(2);
        left.current.style.transform = `rotateY(${angle}deg)`;
        right.current.style.transform = `rotateY(-${angle}deg)`;
        left.current.style.setProperty('--shade', s.toFixed(3));
        right.current.style.setProperty('--shade', s.toFixed(3));

        facade.current.style.transform = `scale(${(1 + c * 2.8).toFixed(3)})`;
        facade.current.style.opacity = (1 - range(c, 0.55, 1)).toFixed(3);
        facade.current.style.visibility = c >= 1 ? 'hidden' : '';
      }

      flood.current.style.opacity = (Math.sin(Math.PI * range(p, 0.12, 0.85)) * 0.75).toFixed(3);
      glow.current.style.opacity = (0.15 + 0.85 * s).toFixed(3);
      glow.current.style.transform = `scale(${(0.6 + 0.6 * s).toFixed(3)})`;
      rays.current.style.opacity = (0.3 * s).toFixed(3);

      const h = easeOut(range(p, 0.18, 0.8));
      hero.current.style.opacity = h.toFixed(3);
      hero.current.style.transform = `scale(${(0.86 + 0.14 * c).toFixed(3)})`;
    };

    const schedule = () => { if (!frame) frame = requestAnimationFrame(render); };
    const remeasure = () => { measure(); door?.resize(); last = -1; schedule(); };

    /* the WebGL door: fetched after first paint so it never delays the page */
    const fallBack = () => {
      door?.dispose();
      door = null;
      nightGL = false;
      html.removeAttribute('data-night-gl');
      stage.current?.removeAttribute('data-gl');
      last = -1;
      schedule();
    };
    const loadNight = async () => {
      const [{ createNightScene }, { webglAvailable }] = await Promise.all([import('@/lib/night/scene'), import('@/lib/doorScene')]);
      if (disposed || !webglAvailable()) return;
      try {
        door = createNightScene(document.getElementById('night-canvas'), { onContextLost: fallBack, onIntro: nightCue(hero) });
      } catch {
        return fallBack();
      }
      nightGL = true;
      html.setAttribute('data-night-gl', '');
      stage.current.setAttribute('data-gl', '');
      hero.current.style.opacity = hero.current.style.transform = '';   // the scene's cue reveals it now
      last = -1;
      schedule();
    };
    const loadDoor = async () => {
      if (night) return loadNight();
      const { createDoorScene, webglAvailable } = await import('@/lib/doorScene');
      if (disposed || !webglAvailable()) return;
      try {
        // ?door=wood / ?door=wood-iron previews the wooden finishes
        const style = new URLSearchParams(window.location.search).get('door') || undefined;
        door = createDoorScene(canvas.current, { onContextLost: fallBack, style });
      } catch {
        return fallBack();
      }
      door.setLive(wasLive !== false);
      stage.current.setAttribute('data-gl', '');
      last = -1;
      schedule();
    };
    const idle = window.requestIdleCallback || (cb => setTimeout(cb, 200));
    idle(() => { loadDoor().catch(() => {}); }, { timeout: 1200 });

    measure();
    render();
    window.addEventListener('scroll', schedule, { passive: true });
    window.addEventListener('resize', remeasure);
    const ro = new ResizeObserver(remeasure);
    ro.observe(document.body);

    /* tap-to-open: a cinematic scroll through the whole hall */
    let tween = 0;
    const cancelTween = () => { cancelAnimationFrame(tween); tween = 0; };
    autoOpen.current = fromDoor => {
      if (fromDoor && window.scrollY > top + total * 0.05) return;   // a tap on the door only opens a closed door
      cancelTween();
      const from = window.scrollY;
      const to = top + total;
      const t0 = performance.now();
      const step = now => {
        const t = clamp((now - t0) / (nightGL ? AUTO_OPEN_MS * 2.6 : AUTO_OPEN_MS));
        window.scrollTo({ top: from + (to - from) * easeInOut(t), behavior: 'instant' });
        tween = t < 1 ? requestAnimationFrame(step) : 0;
      };
      tween = requestAnimationFrame(step);
    };
    // the guest takes over → stop the automatic walk-through
    const userScroll = () => tween && cancelTween();
    window.addEventListener('wheel', userScroll, { passive: true });
    window.addEventListener('touchstart', userScroll, { passive: true });
    window.addEventListener('keydown', userScroll);

    return () => {
      disposed = true;
      door?.dispose();
      cancelAnimationFrame(frame);
      cancelTween();
      ro.disconnect();
      window.removeEventListener('scroll', schedule);
      window.removeEventListener('resize', remeasure);
      window.removeEventListener('wheel', userScroll);
      window.removeEventListener('touchstart', userScroll);
      window.removeEventListener('keydown', userScroll);
    };
  }, []);

  return (
    <section className="hall" id="hall" ref={hall} aria-label="أبواب القاعة">
      <div
        className="stage"
        ref={stage}
        data-open={opened ? '' : undefined}
        onClick={e => { if (!e.target.closest('button')) autoOpen.current?.(true); }}
      >

        {/* the hall interior, revealed behind the doors */}
        <div className="interior">
          <div className="hall-glow" ref={glow} />
          <div className="rays" ref={rays} />
          <div className="hero-inner" ref={hero}>
            <p className="eyebrow">بسم الله نبدأ حكايتنا</p>
            <div className="rule"><span />❖<span /></div>
            <div className="title-ring">💍</div>
            <h1 className="title" data-text="دعوة فرح"><span>دعوة فرح</span></h1>
            <div className="subtitle"><Typing /></div>
            <div className="names"><span>أحمد</span><i className="amp">&amp;</i><span>عبير<small></small></span></div>
            <div className="rule"><span />❖<span /></div>
          </div>
        </div>

        {/* the facade: wall + arched doorway + the two leaves */}
        <div className="facade" ref={facade} aria-hidden="true">
          <div className="doorway">
            <div className="portal">
              <Leaf side="left" leafRef={left} />
              <Leaf side="right" leafRef={right} />
              <span className="seam" ref={seam} />
            </div>
            <div className="frame" />
            <span className="dial" ref={dial} />
            <div className="keystone"><Ornament /></div>
            <span className="step" />
            <span className="sconce l" />
            <span className="sconce r" />
          </div>
        </div>

        <canvas className="door-canvas" ref={canvas} aria-hidden="true" />

        <div className="flood" ref={flood} />

        <button type="button" className="open-hint" ref={hint} onClick={() => autoOpen.current?.()}>
          <span className="mouse"><span className="wheel" /></span>
          <span>اضغط على الباب أو اسحب لأسفل لفتحه</span>
        </button>

      </div>
    </section>
  );
}
