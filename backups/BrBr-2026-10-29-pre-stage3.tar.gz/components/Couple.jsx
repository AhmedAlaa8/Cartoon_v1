import fs from 'node:fs';
import path from 'node:path';
import Image from 'next/image';

/* Drop groom.jpg / bride.jpg (or .png / .webp) into public/assets and the
   photo replaces the silhouette at the next build — served resized and in
   AVIF/WebP by next/image. */
function findPhoto(name) {
  for (const ext of ['jpg', 'jpeg', 'png', 'webp']) {
    const file = `${name}.${ext}`;
    if (fs.existsSync(path.join(process.cwd(), 'public', 'assets', file))) return `/assets/${file}`;
  }
  return null;
}

function GroomSilhouette() {
  return (
    <svg className="sil" viewBox="0 0 120 120" aria-hidden="true">
      <circle cx="60" cy="40" r="19" />
      <path d="M28 112C28 82 43 72 60 72s32 10 32 40" />
      <path d="M50 73l10 19 10-19" />
    </svg>
  );
}

function BrideSilhouette() {
  return (
    <svg className="sil" viewBox="0 0 120 120" aria-hidden="true">
      <circle cx="60" cy="42" r="17" />
      <path d="M32 112C32 84 46 74 60 74s28 10 28 38" />
      <path d="M40 30Q60 12 80 30" />
      <path d="M30 58Q33 98 46 112" />
      <path d="M90 58Q87 98 74 112" />
    </svg>
  );
}

function Person({ kind, caption, photo, Silhouette }) {
  return (
    <figure className="person">
      <div className={`medallion ${kind}`}>
        {photo
          ? <Image className="photo" src={photo} alt={caption} fill sizes="190px" />
          : <Silhouette />}
      </div>
      <figcaption className="pname">{caption}</figcaption>
    </figure>
  );
}

export default function Couple() {
  return (
    <section id="couple" className="scope">
      <h2 className="section-title reveal">العروسان</h2>
      <p className="section-sub reveal">قصةُ حبٍّ تُتوَّج بالزواج</p>

      <div className="couple reveal">
        <Person kind="groom" caption="العريس أحمد" photo={findPhoto('groom')} Silhouette={GroomSilhouette} />
        <div className="couple-heart" aria-hidden="true">❤</div>
        <Person kind="bride" caption="العروس عبير" photo={findPhoto('bride')} Silhouette={BrideSilhouette} />
      </div>
    </section>
  );
}
