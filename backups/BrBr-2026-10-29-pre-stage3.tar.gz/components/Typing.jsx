'use client';

import { useEffect, useRef } from 'react';

const PHRASES = [
  'بفضل الله وكرمه نتشرّف بدعوتكم 🤍',
  'حيث تبدأ أجمل قصص الحب...',
  'لنحتفل معًا بيومٍ لا يُنسى 💍',
  'حضوركم سعادتنا الحقيقية ✨',
];

/* Typewriter: types a phrase, pauses, deletes, moves on — loops.
   It only ticks while it is on screen. */
export default function Typing({ speed = 90 }) {
  const ref = useRef(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      el.textContent = PHRASES[0];
      return;
    }

    let p = 0, i = 0, deleting = false, timer = null, visible = false;

    const tick = () => {
      timer = null;
      if (!visible) return;
      const text = PHRASES[p];
      let wait = deleting ? 40 : speed;
      if (!deleting) {
        el.textContent = text.slice(0, ++i);
        if (i === text.length) { deleting = true; wait = 1900; }
      } else {
        el.textContent = text.slice(0, --i);
        if (i === 0) { deleting = false; p = (p + 1) % PHRASES.length; wait = 350; }
      }
      timer = setTimeout(tick, wait);
    };

    const io = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (visible && !timer) tick();
    });
    io.observe(el);

    return () => { io.disconnect(); clearTimeout(timer); };
  }, [speed]);

  return <span className="typing caret" ref={ref} />;
}
