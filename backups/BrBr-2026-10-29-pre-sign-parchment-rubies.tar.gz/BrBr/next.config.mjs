/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  // a second build can live beside the running one (NEXT_DIST_DIR=.next-3004 for the server on port 3004)
  distDir: process.env.NEXT_DIST_DIR || '.next',
  images: { formats: ['image/avif', 'image/webp'] },
  // the invitation used to be previewed at /cinematic; old links land on the home page
  async redirects() {
    return [{ source: '/cinematic', destination: '/', permanent: false }];
  },
};

export default nextConfig;
