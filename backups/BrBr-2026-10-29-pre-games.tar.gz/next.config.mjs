/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  images: { formats: ['image/avif', 'image/webp'] },
  // the invitation used to be previewed at /cinematic; old links land on the home page
  async redirects() {
    return [{ source: '/cinematic', destination: '/', permanent: false }];
  },
};

export default nextConfig;
