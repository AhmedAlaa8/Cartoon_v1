'use client';

import { useCallback, useEffect, useRef, useState } from 'react';

/* ================================================================
   Cinematic preview shell (Stage 1): six chapters, no page scroll.
   Next = swipe left→right (RTL), the ‹ arrow, ←, PageDown/Space or
   the mouse wheel; each chapter has its own #hash. The 3D world
   (lib/cinematic/scene.js) loads after first paint; the camera
   travels between the chapters' stations.
================================================================ */

const CHAPTERS = [
  { id: 'door', title: 'الباب' },
  { id: 'names', title: 'الأسماء' },
  { id: 'countdown', title: 'العدّ التنازلي' },
  { id: 'couple', title: 'العروسان' },
  { id: 'rsvp', title: 'تأكيد الحضور' },
  { id: 'sky', title: 'الختام' },
];
const indexOfHash = () => Math.max(0, CHAPTERS.findIndex(c => `#${c.id}` === window.location.hash));
// an SVG chevron: text arrows (‹ ›) are mirrored by the RTL bidi algorithm
const Chevron = ({ to }) => (
  <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true">
    <path d={to === 'left' ? 'M15 5l-7 7 7 7' : 'M9 5l7 7-7 7'} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
const toArabic = s => String(s).replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);

/* same target and semantics as components/Countdown.jsx (device time zone)
   until the wedding's date, time and time zone are confirmed */
const TARGET = new Date('2027-07-27T16:00:00').getTime();
const pad = n => String(n).padStart(2, '0');

function useCountdown() {
  const [left, setLeft] = useState(null);
  useEffect(() => {
    const tick = () => {
      const d = Math.max(0, TARGET - Date.now());
      setLeft({
        days: Math.floor(d / 86400000), hours: pad(Math.floor(d % 86400000 / 3600000)),
        minutes: pad(Math.floor(d % 3600000 / 60000)), seconds: pad(Math.floor(d % 60000 / 1000)),
      });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return left;
}

function Medallion({ caption, photo, kind }) {
  return (
    <figure className="cine-person">
      <div className={`cine-medallion ${kind}`}>
        {photo
          ? <img src={photo} alt={caption} />
          : kind === 'groom'
            ? <svg viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="40" r="19" /><path d="M28 112C28 82 43 72 60 72s32 10 32 40" /><path d="M50 73l10 19 10-19" /></svg>
            : <svg viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="42" r="17" /><path d="M32 112C32 84 46 74 60 74s28 10 28 38" /><path d="M40 30Q60 12 80 30" /><path d="M30 58Q33 98 46 112" /><path d="M90 58Q87 98 74 112" /></svg>}
      </div>
      <figcaption>{caption}</figcaption>
    </figure>
  );
}

export default function CinematicApp({ photos = {} }) {
  const root = useRef(null);
  const canvas = useRef(null);
  const scene = useRef(null);
  const busy = useRef(false);
  const [index, setIndex] = useState(0);         // where we are going (dots, hash)
  const [shown, setShown] = useState(0);         // whose words are on screen — only once the camera has arrived
  const [dir, setDir] = useState(1);
  const [ready, setReady] = useState(false);
  const left = useCountdown();

  /* the page itself never scrolls in this mode */
  useEffect(() => {
    document.documentElement.classList.add('cine-mode');
    return () => document.documentElement.classList.remove('cine-mode');
  }, []);

  const go = useCallback(async target => {
    if (target < 0 || target >= CHAPTERS.length || busy.current) return;
    const from = scene.current ? scene.current.index : index;
    if (target === from) return;
    busy.current = true;
    setDir(target > from ? 1 : -1);
    setIndex(target);
    setShown(-1);
    history.replaceState(null, '', `#${CHAPTERS[target].id}`);
    try {
      await scene.current?.goTo(target);
    } finally {
      busy.current = false;
      setShown(target);
    }
  }, [index]);

  /* load the world after first paint */
  useEffect(() => {
    const start = indexOfHash();
    setIndex(start);
    setShown(start);
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let disposed = false;
    const load = async () => {
      const [{ createCinematicScene }, { webglAvailable }] = await Promise.all([import('@/lib/cinematic/scene'), import('@/lib/doorScene')]);
      if (disposed || !webglAvailable()) return;
      scene.current = createCinematicScene(canvas.current, {
        reducedMotion: reduced,
        start: CHAPTERS[start].id,
        // ?slowmo=N slows the world N× — for reviewing transitions frame by frame
        slowmo: Math.max(1, Number(new URLSearchParams(window.location.search).get('slowmo')) || 1),
        onContextLost: () => { scene.current = null; setReady(false); },
      });
      setReady(true);
    };
    const idle = window.requestIdleCallback || (cb => setTimeout(cb, 120));
    idle(() => { load().catch(() => {}); }, { timeout: 800 });
    const onResize = () => scene.current?.resize();
    window.addEventListener('resize', onResize);
    return () => { disposed = true; scene.current?.dispose(); scene.current = null; window.removeEventListener('resize', onResize); };
  }, []);

  /* keyboard, wheel, hash */
  useEffect(() => {
    const onKey = e => {
      if (e.target.closest?.('input, textarea, select')) return;
      if (['ArrowLeft', 'PageDown', ' '].includes(e.key)) { e.preventDefault(); go(index + 1); }
      if (['ArrowRight', 'PageUp'].includes(e.key)) { e.preventDefault(); go(index - 1); }
    };
    let acc = 0, quietUntil = 0;
    const onWheel = e => {
      if (e.target.closest?.('[data-scroll]')) return;
      e.preventDefault();
      const now = performance.now();
      if (now < quietUntil) return;
      acc += e.deltaY;
      if (Math.abs(acc) > 60) {
        go(index + Math.sign(acc));
        acc = 0;
        quietUntil = now + 900;      // one gesture, one chapter
      }
    };
    const onHash = () => go(indexOfHash());
    window.addEventListener('keydown', onKey);
    window.addEventListener('wheel', onWheel, { passive: false });
    window.addEventListener('hashchange', onHash);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('wheel', onWheel);
      window.removeEventListener('hashchange', onHash);
    };
  }, [go, index]);

  /* swipe (left→right = next) and taps */
  const touch = useRef(null);
  const onPointerDown = e => {
    if (e.target.closest('button, a, input, textarea, select, label, [data-no-swipe]')) { touch.current = null; return; }
    touch.current = { x: e.clientX, y: e.clientY, t: performance.now() };
  };
  const onPointerUp = e => {
    const s = touch.current;
    touch.current = null;
    if (!s) return;
    const dx = e.clientX - s.x, dy = e.clientY - s.y, dt = performance.now() - s.t;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.4) { go(index + (dx > 0 ? 1 : -1)); return; }
    if (Math.abs(dx) < 10 && Math.abs(dy) < 10 && dt < 500) {
      if (CHAPTERS[index].id === 'door') go(1);                 // tap the door to enter
      else scene.current?.wish(e.clientX, e.clientY);           // touch the sky (final chapter)
    }
  };

  const c = shown >= 0 ? CHAPTERS[shown].id : null;
  const chapterClass = id => `cine-chapter cine-${id}${c === id ? ' is-active' : ''}`;
  const inactive = id => (c === id ? {} : { inert: true, 'aria-hidden': true });

  return (
    <div
      className={`cine${ready ? ' is-ready' : ''}`}
      data-dir={dir > 0 ? 'next' : 'prev'}
      ref={root}
      onPointerDown={onPointerDown}
      onPointerUp={onPointerUp}
    >
      <canvas className="cine-canvas" ref={canvas} aria-hidden="true" />

      <section className={chapterClass('door')} {...inactive('door')} aria-label="الباب">
        <p className="cine-hint"><span className="cine-tap" aria-hidden="true" />اضغط على الباب للدخول</p>
      </section>

      <section className={chapterClass('names')} {...inactive('names')} aria-label="أحمد وعبير">
        <p className="cine-eyebrow">بسم الله نبدأ حكايتنا</p>
        <h1 className="cine-sr">أحمد ♥ عبير</h1>
        <p className="cine-stage-note">هنا ستكتب الألعاب النارية الأسماء<br /><small>المرحلة ٤</small></p>
      </section>

      <section className={chapterClass('countdown')} {...inactive('countdown')} aria-label="العدّ التنازلي">
        <h2 className="cine-title">العدّ التنازلي ليوم العمر</h2>
        <p className="cine-date">٢٧ يوليو ٢٠٢٧</p>
        <div className="cine-count" role="timer" aria-live="off">
          {[['days', 'يوم'], ['hours', 'ساعة'], ['minutes', 'دقيقة'], ['seconds', 'ثانية']].map(([k, label], i) => (
            <div className="cine-unit" key={k}>
              {i > 0 && <span className="cine-sep" aria-hidden="true">❖</span>}
              <span className="cine-num">{left ? toArabic(left[k]) : '٠٠'}</span>
              <span className="cine-lbl">{label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={chapterClass('couple')} {...inactive('couple')} aria-label="العروسان">
        <h2 className="cine-title">العروسان</h2>
        <div className="cine-pair">
          <Medallion kind="groom" caption="العريس أحمد" photo={photos.groom} />
          <span className="cine-heart" aria-hidden="true">♥</span>
          <Medallion kind="bride" caption="العروس عبير" photo={photos.bride} />
        </div>
      </section>

      <section className={chapterClass('rsvp')} {...inactive('rsvp')} aria-label="تأكيد الحضور">
        <h2 className="cine-title">شرّفونا بحضوركم</h2>
        <p className="cine-text">
          يسعدنا ويشرّفنا دعوتكم لمشاركتنا فرحة العمر، فحضوركم تاجٌ على رؤوسنا وبهجةٌ لقلوبنا.
        </p>
        <p className="cine-stage-note">نموذج التأكيد عند القوس<br /><small>المرحلة ٥</small></p>
      </section>

      <section className={chapterClass('sky')} {...inactive('sky')} aria-label="الختام">
        <p className="cine-verse">«ومن آياته أن خلق لكم من أنفسكم أزواجًا لتسكنوا إليها وجعل بينكم مودّةً ورحمة»</p>
        <p className="cine-wish">المس السماء وأضف نجمتك لليلتنا ✨</p>
      </section>

      <nav className="cine-nav" aria-label="فصول الدعوة">
        <button type="button" className="cine-arrow prev" onClick={() => go(index - 1)} disabled={index === 0} aria-label="الفصل السابق"><Chevron to="right" /></button>
        <div className="cine-dots">
          {CHAPTERS.map((ch, i) => (
            <button
              type="button" key={ch.id} className={`cine-dot${i === index ? ' is-active' : ''}`}
              onClick={() => go(i)} aria-label={ch.title} aria-current={i === index ? 'step' : undefined}
            />
          ))}
        </div>
        <button type="button" className="cine-arrow next" onClick={() => go(index + 1)} disabled={index === CHAPTERS.length - 1} aria-label="الفصل التالي"><Chevron to="left" /></button>
      </nav>
      <p className="cine-sr" aria-live="polite">{`${toArabic(index + 1)} من ٦: ${CHAPTERS[index].title}`}</p>
    </div>
  );
}
